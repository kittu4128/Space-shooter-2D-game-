/* ============================================================
   SPRITE ENGINE — pixel-art sprites drawn on small grids
   then scaled up, matching the chunky retro look in the
   reference image (blue robots, purple ufos, red/pink blobs,
   green-eyed jellies, glowing player ship).
   ============================================================ */

function drawPixelGrid(ctx, x, y, pixelSize, grid, palette) {
  for (let row = 0; row < grid.length; row++) {
    for (let col = 0; col < grid[row].length; col++) {
      const code = grid[row][col];
      if (code === '.' || code === ' ') continue;
      ctx.fillStyle = palette[code] || '#fff';
      ctx.fillRect(
        Math.round(x + col * pixelSize),
        Math.round(y + row * pixelSize),
        pixelSize, pixelSize
      );
    }
  }
}

const SPRITES = {

  // Player ship — purple/lavender fighter with twin engines (matches reference art)
  player: {
    grid: [
      "....A....",
      "...AAA...",
      "...ABA...",
      "..ABBBA..",
      ".AABBBAA.",
      "AABBCBBAA",
      "AABBCBBAA",
      ".A.D.D.A.",
      "...D.D...",
    ],
    palette: { A:'#6a5acd', B:'#9b8cf0', C:'#e0d8ff', D:'#ff8a3d' }
  },

  // Engine flame frames (animated)
  flame: [
    { grid: [".E.","EFE",".E."], palette:{E:'#ff8a3d',F:'#ffe43d'} },
    { grid: ["EFE",".F.","EFE"], palette:{E:'#ff6a1d',F:'#fff08a'} },
  ],

  // Blue robot alien (top row in reference image)
  enemyBlue: {
    grid: [
      ".AAAAA.",
      "AABBBAA",
      "AABCBAA",
      "AABBBAA",
      ".AAAAA.",
      "D.....D",
      "D.....D",
    ],
    palette: { A:'#3d7dff', B:'#1a4fc4', C:'#fff', D:'#2a3a8a' }
  },

  // Purple/yellow UFO alien (2nd row)
  enemyPurple: {
    grid: [
      "..AAAA..",
      ".AABBAA.",
      "AABCCBAA",
      "AABCCBAA",
      ".AABBAA.",
      "D.AAAA.D",
    ],
    palette: { A:'#a04dff', B:'#7a2ad4', C:'#ffe43d', D:'#5a1aa4' }
  },

  // Red/pink crab alien (3rd row)
  enemyRed: {
    grid: [
      "A.....A",
      "AA...AA",
      "AABBBAA",
      "ABBCBBA",
      "AABBBAA",
      "..A.A..",
    ],
    palette: { A:'#ff4f7d', B:'#ff8aa8', C:'#fff', D:'#c41a4a' }
  },

  // Green jellyfish alien (4th row, with tentacles)
  enemyGreen: {
    grid: [
      ".AAAAA.",
      "AABBBAA",
      "AABCBAA",
      "AAAAAAA",
      "D.D.D.D",
      ".D.D.D.",
    ],
    palette: { A:'#5fd44a', B:'#3aa82a', C:'#fff', D:'#2a7a1a' }
  },

  // Hexagon scout (small fast enemy, blue outline like reference)
  enemyHex: {
    grid: [
      "..AA..",
      ".AABA.",
      "ABBBBA",
      "ABBBBA",
      ".AABA.",
      "..AA..",
    ],
    palette: { A:'#2a8fff', B:'#0a1a4a' }
  },

  // Boss — large multi-eyed mothership
  boss: {
    grid: [
      "...AAAAAAAAA...",
      "..AABBBBBBBAA..",
      ".AABBCDCDCBBAA.",
      "AABBBCDCDCBBBAA",
      "AAABBBBBBBBBAAA",
      "..AA.E...E.AA..",
      "...A.......A...",
      "..AA.......AA..",
      ".FF.........FF.",
    ],
    palette: { A:'#7a2ad4', B:'#a04dff', C:'#1a0a3a', D:'#ff4fd8', E:'#ffe43d', F:'#5a1aa4' }
  },

  heart: {
    grid: [
      ".AA.AA.",
      "AAAAAAA",
      "AAAAAAA",
      ".AAAAA.",
      "..AAA..",
      "...A...",
    ],
    palette: { A:'#ff3d8a' }
  },

  planet: {
    grid: [
      "..AAAA..",
      ".AABBAA.",
      "AABBBBAA",
      "AABCBBAA",
      "AABBBBAA",
      ".AABBAA.",
      "..AAAA..",
    ],
    palette: { A:'#e85a3d', B:'#ff8a5a', C:'#ffd4a0' }
  },

  bullet: {
    grid: ["A","A","A"],
    palette: { A:'#9be8ff' }
  },

  enemyBullet: {
    grid: ["A","A"],
    palette: { A:'#ff5a5a' }
  },
};

// Star field background (procedural, parallax)
function makeStarfield(count, w, h) {
  const stars = [];
  for (let i = 0; i < count; i++) {
    stars.push({
      x: Math.random() * w,
      y: Math.random() * h,
      size: Math.random() < 0.85 ? 1 : 2,
      speed: 0.3 + Math.random() * 1.8,
      twinkle: Math.random() * Math.PI * 2,
      color: Math.random() < 0.15 ? '#ff9bd8' : (Math.random() < 0.3 ? '#9be8ff' : '#ffffff')
    });
  }
  return stars;
}

function drawStarfield(ctx, stars, w, h, dt) {
  stars.forEach(s => {
    s.y += s.speed * dt * 60;
    if (s.y > h) { s.y = -2; s.x = Math.random() * w; }
    s.twinkle += dt * 3;
    const alpha = 0.5 + 0.5 * Math.sin(s.twinkle);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = s.color;
    ctx.fillRect(Math.round(s.x), Math.round(s.y), s.size, s.size);
  });
  ctx.globalAlpha = 1;
}

// Drifting nebula clouds — soft, slow-moving colored blobs behind the stars
function makeNebulae(count, w, h) {
  const colors = ['#ff4fd8', '#a020f0', '#4ad4ff', '#ff8a3d', '#3d7dff'];
  const clouds = [];
  for (let i = 0; i < count; i++) {
    clouds.push({
      x: Math.random() * w,
      y: Math.random() * h,
      r: 80 + Math.random() * 140,
      color: colors[i % colors.length],
      driftX: (Math.random() - 0.5) * 6,
      driftY: 4 + Math.random() * 10,
      pulse: Math.random() * Math.PI * 2,
      baseAlpha: 0.05 + Math.random() * 0.05,
    });
  }
  return clouds;
}

function drawNebulae(ctx, clouds, w, h, dt) {
  clouds.forEach(c => {
    c.x += c.driftX * dt;
    c.y += c.driftY * dt;
    c.pulse += dt * 0.5;
    if (c.y - c.r > h) { c.y = -c.r; c.x = Math.random() * w; }
    if (c.x < -c.r) c.x = w + c.r;
    if (c.x > w + c.r) c.x = -c.r;

    const alpha = c.baseAlpha + Math.sin(c.pulse) * 0.02;
    const grad = ctx.createRadialGradient(c.x, c.y, 0, c.x, c.y, c.r);
    grad.addColorStop(0, c.color);
    grad.addColorStop(1, 'transparent');
    ctx.globalAlpha = Math.max(0, alpha);
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(c.x, c.y, c.r, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.globalAlpha = 1;
}

// Occasional fast shooting stars streaking diagonally across the background
function makeShootingStarState() {
  return { active: [], timer: 1.5 + Math.random() * 3 };
}

function updateAndDrawShootingStars(ctx, state, w, h, dt) {
  state.timer -= dt;
  if (state.timer <= 0) {
    state.timer = 2 + Math.random() * 4;
    state.active.push({
      x: Math.random() * w * 0.6 + w * 0.2,
      y: -10,
      vx: 90 + Math.random() * 60,
      vy: 260 + Math.random() * 120,
      life: 1,
      len: 30 + Math.random() * 20,
    });
  }
  for (let i = state.active.length - 1; i >= 0; i--) {
    const s = state.active[i];
    s.x += s.vx * dt;
    s.y += s.vy * dt;
    s.life -= dt * 0.8;
    if (s.life <= 0 || s.y > h + 20) { state.active.splice(i, 1); continue; }

    const angle = Math.atan2(s.vy, s.vx);
    const tailX = s.x - Math.cos(angle) * s.len;
    const tailY = s.y - Math.sin(angle) * s.len;
    const grad = ctx.createLinearGradient(s.x, s.y, tailX, tailY);
    grad.addColorStop(0, `rgba(255,255,255,${s.life})`);
    grad.addColorStop(1, 'transparent');
    ctx.strokeStyle = grad;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(s.x, s.y);
    ctx.lineTo(tailX, tailY);
    ctx.stroke();
  }
}

// Slow drifting background planets — distant, parallax-slow, purely decorative
function makeBgPlanets(count, w, h) {
  const palettes = [
    { A:'#e85a3d', B:'#ff8a5a', C:'#ffd4a0' },
    { A:'#5a3de8', B:'#8a5aff', C:'#d4c4ff' },
    { A:'#3de8a0', B:'#5affc4', C:'#c4ffe0' },
  ];
  const planets = [];
  for (let i = 0; i < count; i++) {
    planets.push({
      x: Math.random() * w,
      y: Math.random() * h,
      scale: 3 + Math.random() * 4,
      speed: 2 + Math.random() * 4,
      palette: palettes[i % palettes.length],
    });
  }
  return planets;
}

function drawBgPlanets(ctx, planets, w, h, dt) {
  planets.forEach(p => {
    p.y += p.speed * dt;
    if (p.y > h + 60) { p.y = -60; p.x = Math.random() * w; }
    const grid = SPRITES.planet.grid;
    const px = p.x - (grid[0].length * p.scale) / 2;
    ctx.globalAlpha = 0.55;
    drawPixelGrid(ctx, px, p.y, p.scale, grid, p.palette);
    ctx.globalAlpha = 1;
  });
}
