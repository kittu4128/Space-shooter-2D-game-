/* ============================================================
   AUDIO ENGINE — fully procedural chiptune music + SFX
   No external audio files needed; everything is synthesized
   live with the Web Audio API so the game works instantly.
   ============================================================ */

class AudioEngine {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.musicGain = null;
    this.sfxGain = null;
    this.muted = false;
    this.musicTimer = null;
    this.musicStep = 0;
    this.currentPattern = null;
    this.started = false;
  }

  init() {
    if (this.started) return;
    this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    this.master = this.ctx.createGain();
    this.master.gain.value = 1;
    this.master.connect(this.ctx.destination);

    this.musicGain = this.ctx.createGain();
    this.musicGain.gain.value = 0.22;
    this.musicGain.connect(this.master);

    this.sfxGain = this.ctx.createGain();
    this.sfxGain.gain.value = 0.35;
    this.sfxGain.connect(this.master);

    this.started = true;
  }

  setMuted(m) {
    this.muted = m;
    if (this.master) this.master.gain.value = m ? 0 : 1;
  }

  toggleMute() {
    this.setMuted(!this.muted);
    return this.muted;
  }

  resume() {
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
  }

  // ---------- low level synth helpers ----------
  _osc(freq, type, t0, dur, gainNode, vol = 1, glideTo = null) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    if (glideTo) osc.frequency.exponentialRampToValueAtTime(glideTo, t0 + dur);
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g);
    g.connect(gainNode);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
    return osc;
  }

  _noise(t0, dur, gainNode, vol = 1, filterFreq = 2000) {
    if (!this.ctx) return;
    const bufferSize = this.ctx.sampleRate * dur;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;
    const filt = this.ctx.createBiquadFilter();
    filt.type = 'lowpass';
    filt.frequency.value = filterFreq;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    noise.connect(filt);
    filt.connect(g);
    g.connect(gainNode);
    noise.start(t0);
    noise.stop(t0 + dur + 0.02);
  }

  // ---------- SFX ----------
  playShoot() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this._osc(880, 'square', t, 0.08, this.sfxGain, 0.18, 1400);
  }

  playEnemyShoot() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this._osc(300, 'sawtooth', t, 0.1, this.sfxGain, 0.12, 150);
  }

  playExplosion(big = false) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this._noise(t, big ? 0.45 : 0.22, this.sfxGain, big ? 0.5 : 0.32, big ? 1200 : 2200);
    this._osc(big ? 140 : 220, 'triangle', t, big ? 0.4 : 0.18, this.sfxGain, 0.3, 40);
  }

  playHit() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this._osc(180, 'sawtooth', t, 0.18, this.sfxGain, 0.3, 60);
    this._noise(t, 0.15, this.sfxGain, 0.25, 800);
  }

  playPowerup() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    [523, 659, 784, 1046].forEach((f, i) => {
      this._osc(f, 'square', t + i * 0.06, 0.12, this.sfxGain, 0.2);
    });
  }

  playLevelClear() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    [523, 659, 784, 1046, 1318].forEach((f, i) => {
      this._osc(f, 'triangle', t + i * 0.1, 0.25, this.sfxGain, 0.28);
    });
  }

  playGameOver() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    [400, 350, 300, 200, 120].forEach((f, i) => {
      this._osc(f, 'sawtooth', t + i * 0.15, 0.3, this.sfxGain, 0.28);
    });
  }

  playBossAlarm() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    for (let i = 0; i < 3; i++) {
      this._osc(660, 'square', t + i * 0.25, 0.15, this.sfxGain, 0.22, 440);
    }
  }

  playUIClick() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this._osc(700, 'square', t, 0.06, this.sfxGain, 0.15, 1000);
  }

  // ---------- MUSIC ----------
  // Simple looping chiptune sequencer. Each pattern is an array of steps;
  // each step: [bassFreq|null, leadFreq|null, useHat(bool)]
  startMusic(patternName = 'main') {
    this.stopMusic();
    const patterns = this._patterns();
    this.currentPattern = patterns[patternName] || patterns.main;
    this.musicStep = 0;
    const stepTime = this.currentPattern.tempo;

    const tick = () => {
      if (!this.ctx || this.muted === undefined) {}
      this._playMusicStep();
      this.musicTimer = setTimeout(tick, stepTime * 1000);
    };
    tick();
  }

  stopMusic() {
    if (this.musicTimer) clearTimeout(this.musicTimer);
    this.musicTimer = null;
  }

  _playMusicStep() {
    if (!this.ctx || !this.currentPattern) return;
    const pat = this.currentPattern;
    const step = pat.steps[this.musicStep % pat.steps.length];
    const t = this.ctx.currentTime;
    const [bass, lead, hat, kick] = step;

    if (kick) this._noise(t, 0.08, this.musicGain, 0.35, 150);
    if (bass) this._osc(bass, 'square', t, pat.tempo * 0.9, this.musicGain, 0.16);
    if (lead) this._osc(lead, 'square', t, pat.tempo * 0.55, this.musicGain, 0.13);
    if (hat) this._noise(t, 0.04, this.musicGain, 0.08, 6000);

    this.musicStep++;
  }

  _patterns() {
    // Frequencies chosen for a driving minor-key retro arcade feel
    const N = null;
    return {
      main: {
        tempo: 0.165,
        steps: [
          [110, 440, 1, 1], [N, N, 0, 0], [110, 523, 1, 0], [N, N, 0, 1],
          [146, 440, 1, 0], [N, N, 0, 0], [146, 587, 1, 0], [N, N, 0, 1],
          [110, 466, 1, 1], [N, N, 0, 0], [110, 523, 1, 0], [N, N, 0, 1],
          [98,  440, 1, 0], [N, N, 0, 0], [98,  392, 1, 0], [N, N, 0, 1],
        ]
      },
      boss: {
        tempo: 0.13,
        steps: [
          [82, 622, 1, 1], [82, N, 1, 0], [82, 659, 1, 1], [82, N, 1, 0],
          [98, 622, 1, 1], [98, N, 1, 0], [98, 698, 1, 1], [98, N, 1, 0],
          [73, 587, 1, 1], [73, N, 1, 0], [73, 622, 1, 1], [73, N, 1, 0],
          [87, 554, 1, 1], [87, N, 1, 1], [87, 523, 1, 1], [87, N, 1, 1],
        ]
      },
      victory: {
        tempo: 0.18,
        steps: [
          [110, 659, 0, 1], [N, 784, 0, 0], [110, 880, 0, 0], [N, 784, 0, 1],
          [146, 659, 0, 0], [N, 880, 0, 0], [146, 1046, 0, 0], [N, N, 0, 1],
        ]
      }
    };
  }
}

const AUDIO = new AudioEngine();
