/* ============================================================
   SPACE SHOOTER by Gauransh Grover — Main Game Engine
   ============================================================ */

(() => {
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;

  // ---------- DOM refs ----------
  const el = id => document.getElementById(id);
  const loadingScreen = el('loadingScreen');
  const startScreen = el('startScreen');
  const pauseScreen = el('pauseScreen');
  const levelClearScreen = el('levelClearScreen');
  const gameOverScreen = el('gameOverScreen');
  const victoryScreen = el('victoryScreen');
  const hud = el('hud');
  const pauseHint = el('pauseHint');
  const loadingBarInner = el('loadingBarInner');
  const loadingLabel = el('loadingLabel');
  const scoreEl = el('score');
  const levelNumEl = el('levelNum');
  const heartsEl = el('hearts');
  const bossBarWrap = el('bossBarWrap');
  const bossBarInner = el('bossBarInner');
  const bossNameEl = el('bossName');
  const levelClearText = el('levelClearText');
  const finalScoreText = el('finalScoreText');
  const victoryText = el('victoryText');

  const TOTAL_LEVELS = 3;

  // ============================================================
  // LOADING SEQUENCE
  // ============================================================
  const loadingSteps = [
    'CALIBRATING THRUSTERS...',
    'LOADING STAR CHARTS...',
    'TUNING WEAPON SYSTEMS...',
    'SYNCING AUDIO CORE...',
    'WAKING UP ALIENS...',
    'READY FOR LAUNCH!'
  ];
  let loadProgress = 0;
  function runLoadingSequence() {
    let stepIdx = 0;
    loadingLabel.textContent = loadingSteps[0];
    const interval = setInterval(() => {
      loadProgress += 4 + Math.random() * 10;
      if (loadProgress >= 100) {
        loadProgress = 100;
        loadingBarInner.style.width = '100%';
        loadingLabel.textContent = loadingSteps[loadingSteps.length - 1];
        clearInterval(interval);
        setTimeout(() => {
          loadingScreen.classList.add('hidden');
          startScreen.classList.remove('hidden');
        }, 450);
        return;
      }
      loadingBarInner.style.width = loadProgress + '%';
      const newStep = Math.min(loadingSteps.length - 2, Math.floor((loadProgress / 100) * (loadingSteps.length - 1)));
      if (newStep !== stepIdx) { stepIdx = newStep; loadingLabel.textContent = loadingSteps[stepIdx]; }
    }, 140);
  }
  window.addEventListener('load', () => setTimeout(runLoadingSequence, 250));

  // ============================================================
  // INPUT
  // ============================================================
  const keys = {};
  window.addEventListener('keydown', e => {
    keys[e.key.toLowerCase()] = true;
    if (e.key === ' ') e.preventDefault();
    if (e.key.toLowerCase() === 'p') togglePause();
    if (e.key.toLowerCase() === 'm') toggleMute();
  });
  window.addEventListener('keyup', e => { keys[e.key.toLowerCase()] = false; });

  // mobile controls
  function bindHold(elm, onDown, onUp) {
    if (!elm) return;
    const down = ev => { ev.preventDefault(); onDown(); };
    const up = ev => { ev.preventDefault(); onUp(); };
    elm.addEventListener('touchstart', down);
    elm.addEventListener('touchend', up);
    elm.addEventListener('mousedown', down);
    elm.addEventListener('mouseup', up);
    elm.addEventListener('mouseleave', up);
  }
  bindHold(el('leftBtn'), () => keys['arrowleft'] = true, () => keys['arrowleft'] = false);
  bindHold(el('rightBtn'), () => keys['arrowright'] = true, () => keys['arrowright'] = false);
  bindHold(el('fireBtn'), () => keys[' '] = true, () => keys[' '] = false);

  // ============================================================
  // GAME STATE
  // ============================================================
  let state = 'menu'; // menu | playing | paused | levelclear | gameover | victory
  let score = 0;
  let lives = 3;
  let level = 1;
  let muted = false;

  let player, bullets, enemyBullets, enemies, particles, stars, powerups, nebulae, shootingStars, bgPlanets;
  let waveTimer = 0, waveIndex = 0, levelData = null;
  let boss = null, bossActive = false;
  let shootCooldown = 0;
  let invuln = 0;
  let lastTime = 0;
  let screenShake = 0;
  let levelTransitioning = false;

  stars = makeStarfield(90, W, H);
  nebulae = makeNebulae(5, W, H);
  shootingStars = makeShootingStarState();
  bgPlanets = makeBgPlanets(2, W, H);

  function resetPlayer() {
    player = {
      x: W / 2 - 16, y: H - 90, w: 32, h: 28,
      speed: 230, alive: true, flameFrame: 0, flameTimer: 0
    };
  }

  function startNewGame() {
    score = 0; lives = 3; level = 1;
    resetPlayer();
    bullets = []; enemyBullets = []; enemies = []; particles = []; powerups = [];
    boss = null; bossActive = false;
    loadLevel(level);
    state = 'playing';
    updateHUD();
    hud.classList.remove('hidden');
    pauseHint.classList.remove('hidden');
    AUDIO.startMusic('main');
  }

  // ============================================================
  // LEVEL DEFINITIONS
  // ============================================================
  function getLevelConfig(lvl) {
    const configs = {
      1: {
        name: 'SECTOR 1 — OUTER RIM',
        waves: [
          { type: 'grid', rows: 3, cols: 5, enemyTypes: ['enemyBlue'], hp: 1, speed: 40 },
          { type: 'grid', rows: 3, cols: 6, enemyTypes: ['enemyBlue','enemyPurple'], hp: 1, speed: 50 },
          { type: 'grid', rows: 4, cols: 6, enemyTypes: ['enemyPurple','enemyRed'], hp: 1, speed: 55 },
        ],
        boss: { name: 'SENTINEL DRONE', hp: 60, sprite: 'boss', speed: 70 }
      },
      2: {
        name: 'SECTOR 2 — ASTEROID BELT',
        waves: [
          { type: 'grid', rows: 4, cols: 6, enemyTypes: ['enemyRed','enemyGreen'], hp: 1, speed: 55 },
          { type: 'grid', rows: 4, cols: 6, enemyTypes: ['enemyGreen','enemyHex'], hp: 2, speed: 65 },
          { type: 'grid', rows: 4, cols: 7, enemyTypes: ['enemyHex','enemyBlue','enemyPurple'], hp: 2, speed: 70 },
        ],
        boss: { name: 'VOID HARVESTER', hp: 100, sprite: 'boss', speed: 85 }
      },
      3: {
        name: 'SECTOR 3 — DEEP VOID',
        waves: [
          { type: 'grid', rows: 4, cols: 7, enemyTypes: ['enemyRed','enemyPurple','enemyGreen'], hp: 2, speed: 70 },
          { type: 'grid', rows: 5, cols: 7, enemyTypes: ['enemyHex','enemyBlue'], hp: 2, speed: 80 },
          { type: 'grid', rows: 5, cols: 8, enemyTypes: ['enemyGreen','enemyRed','enemyHex'], hp: 3, speed: 90 },
        ],
        boss: { name: 'GALAXY DEVOURER', hp: 160, sprite: 'boss', speed: 100 }
      }
    };
    return configs[lvl] || configs[1];
  }

  function loadLevel(lvl) {
    levelData = getLevelConfig(lvl);
    waveIndex = 0;
    enemies = [];
    bossActive = false;
    boss = null;
    bossBarWrap.style.display = 'none';
    spawnWave(levelData.waves[0]);
    updateHUD();
  }

  function spawnWave(wave) {
    enemies = [];
    const marginX = 50, marginTop = 60;
    const spacingX = (W - marginX * 2) / (wave.cols - 1 || 1);
    const spacingY = 42;
    for (let r = 0; r < wave.rows; r++) {
      for (let c = 0; c < wave.cols; c++) {
        const type = wave.enemyTypes[(r + c) % wave.enemyTypes.length];
        enemies.push({
          x: marginX + c * spacingX - 14,
          y: marginTop + r * spacingY - 140, // start off-screen, drop in
          targetY: marginTop + r * spacingY,
          w: 28, h: 24,
          type, hp: wave.hp, maxHp: wave.hp,
          baseX: marginX + c * spacingX - 14,
          phase: Math.random() * Math.PI * 2,
          speed: wave.speed,
          shootTimer: 1 + Math.random() * 3,
          dropping: true,
        });
      }
    }
  }

  // ============================================================
  // UPDATE HELPERS
  // ============================================================
  function updateHUD() {
    scoreEl.textContent = score;
    levelNumEl.textContent = level;
    heartsEl.innerHTML = '♥'.repeat(Math.max(0, lives)) + '<span style="opacity:0.25">' + '♥'.repeat(Math.max(0, 3 - lives)) + '</span>';
  }

  function spawnParticles(x, y, color, count = 10, speed = 80) {
    for (let i = 0; i < count; i++) {
      const ang = Math.random() * Math.PI * 2;
      particles.push({
        x, y,
        vx: Math.cos(ang) * speed * (0.3 + Math.random()),
        vy: Math.sin(ang) * speed * (0.3 + Math.random()),
        life: 0.4 + Math.random() * 0.4,
        maxLife: 0.4 + Math.random() * 0.4,
        color, size: 2 + Math.random() * 2
      });
    }
  }

  function rectsOverlap(a, b) {
    return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  }

  // ============================================================
  // MAIN UPDATE
  // ============================================================
  function update(dt) {
    if (state !== 'playing') return;

    // --- player movement ---
    const moveLeft = keys['arrowleft'] || keys['a'];
    const moveRight = keys['arrowright'] || keys['d'];
    if (moveLeft) player.x -= player.speed * dt;
    if (moveRight) player.x += player.speed * dt;
    player.x = Math.max(6, Math.min(W - player.w - 6, player.x));

    player.flameTimer += dt;
    if (player.flameTimer > 0.1) { player.flameTimer = 0; player.flameFrame = (player.flameFrame + 1) % 2; }

    // --- shooting ---
    shootCooldown -= dt;
    if ((keys[' ']) && shootCooldown <= 0 && player.alive) {
      bullets.push({ x: player.x + player.w / 2 - 2, y: player.y - 4, w: 4, h: 12, speed: 480 });
      bullets.push({ x: player.x + 6, y: player.y + 4, w: 3, h: 10, speed: 460 });
      bullets.push({ x: player.x + player.w - 9, y: player.y + 4, w: 3, h: 10, speed: 460 });
      shootCooldown = 0.18;
      AUDIO.playShoot();
    }

    if (invuln > 0) invuln -= dt;
    if (screenShake > 0) screenShake -= dt;

    // --- bullets ---
    bullets.forEach(b => b.y -= b.speed * dt);
    bullets = bullets.filter(b => b.y > -20);

    enemyBullets.forEach(b => b.y += b.speed * dt);
    enemyBullets = enemyBullets.filter(b => b.y < H + 20);

    // --- particles ---
    particles.forEach(p => {
      p.x += p.vx * dt; p.y += p.vy * dt; p.life -= dt;
      p.vx *= 0.95; p.vy *= 0.95;
    });
    particles = particles.filter(p => p.life > 0);

    // --- powerups ---
    powerups.forEach(p => p.y += 60 * dt);
    powerups = powerups.filter(p => p.y < H + 20);

    if (!bossActive) updateWaveEnemies(dt);
    else updateBoss(dt);

    handleCollisions();

    // wave clear check
    if (!bossActive && enemies.length === 0 && !levelTransitioning) {
      waveIndex++;
      if (waveIndex < levelData.waves.length) {
        setTimeout(() => { if (state === 'playing') spawnWave(levelData.waves[waveIndex]); }, 900);
        levelTransitioning = true;
        setTimeout(() => { levelTransitioning = false; }, 950);
      } else {
        startBossFight();
      }
    }
  }

  function updateWaveEnemies(dt) {
    enemies.forEach(en => {
      if (en.dropping) {
        en.y += 160 * dt;
        if (en.y >= en.targetY) { en.y = en.targetY; en.dropping = false; }
        return;
      }
      en.phase += dt * 1.6;
      en.x = en.baseX + Math.sin(en.phase) * 26;
      en.y += Math.sin(en.phase * 0.5) * 0.3 + en.speed * dt * 0.05;

      en.shootTimer -= dt;
      if (en.shootTimer <= 0) {
        en.shootTimer = 1.5 + Math.random() * 3;
        if (Math.random() < 0.6) {
          enemyBullets.push({ x: en.x + en.w / 2 - 2, y: en.y + en.h, w: 4, h: 10, speed: 200 + level * 20 });
          AUDIO.playEnemyShoot();
        }
      }
    });
  }

  function startBossFight() {
    bossActive = true;
    const cfg = levelData.boss;
    boss = {
      x: W / 2 - 60, y: -130, targetY: 95, w: 120, h: 70,
      hp: cfg.hp, maxHp: cfg.hp, speed: cfg.speed,
      phase: 0, shootTimer: 1.5, name: cfg.name, entering: true,
      flashTimer: 0, attackPattern: 0, patternTimer: 4,
    };
    bossNameEl.textContent = cfg.name;
    bossBarWrap.style.display = 'block';
    bossBarInner.style.width = '100%';
    AUDIO.playBossAlarm();
    AUDIO.startMusic('boss');
  }

  function updateBoss(dt) {
    if (!boss) return;
    if (boss.entering) {
      boss.y += 60 * dt;
      if (boss.y >= boss.targetY) { boss.y = boss.targetY; boss.entering = false; }
      return;
    }
    boss.phase += dt;
    boss.x = W / 2 - boss.w / 2 + Math.sin(boss.phase * 0.6) * (W / 2 - boss.w / 2 - 10);
    if (boss.flashTimer > 0) boss.flashTimer -= dt;

    boss.patternTimer -= dt;
    if (boss.patternTimer <= 0) {
      boss.attackPattern = (boss.attackPattern + 1) % 3;
      boss.patternTimer = 4 + Math.random() * 2;
    }

    boss.shootTimer -= dt;
    if (boss.shootTimer <= 0) {
      boss.shootTimer = Math.max(0.35, 1.1 - level * 0.15);
      fireBossPattern();
      AUDIO.playEnemyShoot();
    }
  }

  function fireBossPattern() {
    const cx = boss.x + boss.w / 2;
    const cy = boss.y + boss.h - 5;
    const speed = 180 + level * 25;
    if (boss.attackPattern === 0) {
      // spread shot
      for (let i = -2; i <= 2; i++) {
        enemyBullets.push({ x: cx - 2, y: cy, w: 4, h: 10, speed, vx: i * 40 });
      }
    } else if (boss.attackPattern === 1) {
      // double aimed burst
      enemyBullets.push({ x: cx - 30, y: cy, w: 4, h: 10, speed });
      enemyBullets.push({ x: cx + 26, y: cy, w: 4, h: 10, speed });
    } else {
      // wide fan
      for (let i = -3; i <= 3; i++) {
        enemyBullets.push({ x: cx - 2, y: cy, w: 4, h: 10, speed: speed * 0.9, vx: i * 55 });
      }
    }
  }

  // update enemy bullets with optional horizontal drift (vx)
  function updateEnemyBulletDrift(dt) {
    enemyBullets.forEach(b => { if (b.vx) b.x += b.vx * dt; });
  }

  function handleCollisions() {
    // player bullets vs enemies
    for (let i = enemies.length - 1; i >= 0; i--) {
      const en = enemies[i];
      for (let j = bullets.length - 1; j >= 0; j--) {
        const b = bullets[j];
        if (rectsOverlap(b, en)) {
          bullets.splice(j, 1);
          en.hp--;
          if (en.hp <= 0) {
            const colorMap = { enemyBlue:'#3d7dff', enemyPurple:'#a04dff', enemyRed:'#ff4f7d', enemyGreen:'#5fd44a', enemyHex:'#2a8fff' };
            spawnParticles(en.x + en.w/2, en.y + en.h/2, colorMap[en.type] || '#fff', 14);
            enemies.splice(i, 1);
            score += 10 * level;
            AUDIO.playExplosion(false);
            maybeDropPowerup(en.x + en.w/2, en.y + en.h/2);
          } else {
            AUDIO.playHit();
          }
          break;
        }
      }
    }

    // player bullets vs boss
    if (bossActive && boss && !boss.entering) {
      for (let j = bullets.length - 1; j >= 0; j--) {
        if (!boss) break; // boss may have been defeated by a bullet earlier this same frame
        const b = bullets[j];
        if (rectsOverlap(b, boss)) {
          bullets.splice(j, 1);
          boss.hp--;
          boss.flashTimer = 0.08;
          score += 5;
          bossBarInner.style.width = Math.max(0, (boss.hp / boss.maxHp) * 100) + '%';
          if (boss.hp <= 0) {
            defeatBoss();
          } else {
            AUDIO.playHit();
          }
        }
      }
    }

    // enemy bullets vs player
    if (player.alive && invuln <= 0) {
      for (let k = enemyBullets.length - 1; k >= 0; k--) {
        if (rectsOverlap(enemyBullets[k], player)) {
          enemyBullets.splice(k, 1);
          damagePlayer();
          break;
        }
      }
      // enemies colliding with player (ramming)
      for (let i = enemies.length - 1; i >= 0; i--) {
        if (rectsOverlap(enemies[i], player)) {
          spawnParticles(enemies[i].x, enemies[i].y, '#fff', 10);
          enemies.splice(i, 1);
          damagePlayer();
          break;
        }
      }
      // boss body collision
      if (bossActive && boss && !boss.entering && rectsOverlap(boss, player)) {
        damagePlayer();
      }
    }

    // powerup pickup
    for (let i = powerups.length - 1; i >= 0; i--) {
      if (rectsOverlap(powerups[i], { x: player.x, y: player.y, w: player.w, h: player.h })) {
        applyPowerup(powerups[i].kind);
        powerups.splice(i, 1);
        AUDIO.playPowerup();
      }
    }
  }

  function maybeDropPowerup(x, y) {
    if (Math.random() < 0.08) {
      powerups.push({ x: x - 8, y, w: 16, h: 16, kind: 'life' });
    }
  }

  function applyPowerup(kind) {
    if (kind === 'life') { lives = Math.min(5, lives + 1); updateHUD(); }
  }

  function damagePlayer() {
    lives--;
    invuln = 1.2;
    screenShake = 0.3;
    spawnParticles(player.x + player.w/2, player.y + player.h/2, '#ff4f7d', 16, 120);
    AUDIO.playExplosion(false);
    updateHUD();
    if (lives <= 0) {
      triggerGameOver();
    }
  }

  function defeatBoss() {
    spawnParticles(boss.x + boss.w/2, boss.y + boss.h/2, '#ff4fd8', 40, 160);
    spawnParticles(boss.x + boss.w/2, boss.y + boss.h/2, '#ffe43d', 30, 130);
    AUDIO.playExplosion(true);
    score += 200 * level;
    bossActive = false;
    boss = null;
    bossBarWrap.style.display = 'none';
    enemyBullets = [];
    AUDIO.stopMusic();
    setTimeout(() => triggerLevelClear(), 700);
  }

  // ============================================================
  // RENDER
  // ============================================================
  function render(dt) {
    ctx.clearRect(0, 0, W, H);

    // background gradient
    const grad = ctx.createRadialGradient(W/2, H*0.3, 50, W/2, H/2, H*0.9);
    grad.addColorStop(0, '#1a0f33');
    grad.addColorStop(1, '#05030f');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    drawNebulae(ctx, nebulae, W, H, dt);
    drawBgPlanets(ctx, bgPlanets, W, H, dt);
    drawStarfield(ctx, stars, W, H, dt);
    updateAndDrawShootingStars(ctx, shootingStars, W, H, dt);

    let shakeX = 0, shakeY = 0;
    if (screenShake > 0) {
      shakeX = (Math.random() - 0.5) * 6 * screenShake;
      shakeY = (Math.random() - 0.5) * 6 * screenShake;
      ctx.save();
      ctx.translate(shakeX, shakeY);
    }

    if (state === 'playing' || state === 'paused') {
      drawWorld();
    }

    if (screenShake > 0) ctx.restore();
  }

  function drawWorld() {
    // player
    if (player.alive) {
      const flicker = invuln > 0 && Math.floor(invuln * 10) % 2 === 0;
      if (!flicker) {
        const ps = 3.4;
        drawPixelGrid(ctx, player.x - 4, player.y - 6, ps, SPRITES.player.grid, SPRITES.player.palette);
        const f = SPRITES.flame[player.flameFrame];
        drawPixelGrid(ctx, player.x + 4, player.y + player.h - 8, ps * 0.9, f.grid, f.palette);
        drawPixelGrid(ctx, player.x + player.w - 14, player.y + player.h - 8, ps * 0.9, f.grid, f.palette);
      }
    }

    // bullets (player) — glowing
    ctx.save();
    bullets.forEach(b => {
      ctx.shadowColor = '#9be8ff'; ctx.shadowBlur = 6;
      ctx.fillStyle = '#9be8ff';
      ctx.fillRect(b.x, b.y, b.w, b.h);
    });
    ctx.restore();

    // enemy bullets
    ctx.save();
    enemyBullets.forEach(b => {
      ctx.shadowColor = '#ff5a5a'; ctx.shadowBlur = 6;
      ctx.fillStyle = '#ff5a5a';
      ctx.fillRect(b.x, b.y, b.w, b.h);
    });
    ctx.restore();

    // enemies
    const spriteMap = { enemyBlue:'enemyBlue', enemyPurple:'enemyPurple', enemyRed:'enemyRed', enemyGreen:'enemyGreen', enemyHex:'enemyHex' };
    enemies.forEach(en => {
      const s = SPRITES[spriteMap[en.type]];
      drawPixelGrid(ctx, en.x, en.y, 4, s.grid, s.palette);
      if (en.maxHp > 1) {
        // mini health bar
        ctx.fillStyle = 'rgba(0,0,0,0.4)';
        ctx.fillRect(en.x, en.y - 6, en.w, 3);
        ctx.fillStyle = '#5fd44a';
        ctx.fillRect(en.x, en.y - 6, en.w * (en.hp / en.maxHp), 3);
      }
    });

    // boss
    if (bossActive && boss) {
      ctx.save();
      if (boss.flashTimer > 0) {
        ctx.filter = 'brightness(2)';
      }
      const scale = boss.w / 15;
      drawPixelGrid(ctx, boss.x, boss.y, scale, SPRITES.boss.grid, SPRITES.boss.palette);
      ctx.restore();
    }

    // powerups
    powerups.forEach(p => {
      drawPixelGrid(ctx, p.x, p.y, 2.6, SPRITES.heart.grid, SPRITES.heart.palette);
    });

    // particles
    particles.forEach(p => {
      ctx.globalAlpha = Math.max(0, p.life / p.maxLife);
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x, p.y, p.size, p.size);
    });
    ctx.globalAlpha = 1;
  }

  // ============================================================
  // GAME LOOP
  // ============================================================
  function loop(timestamp) {
    if (!lastTime) lastTime = timestamp;
    const dt = Math.min(0.05, (timestamp - lastTime) / 1000);
    lastTime = timestamp;

    updateEnemyBulletDrift(dt);
    update(dt);
    render(dt);

    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

  // ============================================================
  // STATE TRANSITIONS
  // ============================================================
  function togglePause() {
    if (state === 'playing') {
      state = 'paused';
      pauseScreen.classList.remove('hidden');
    } else if (state === 'paused') {
      state = 'playing';
      pauseScreen.classList.add('hidden');
      lastTime = 0;
    }
  }

  function toggleMute() {
    muted = AUDIO.toggleMute();
    el('muteBtnStart').textContent = muted ? '🔇 SOUND OFF' : '🔊 SOUND ON';
  }

  function triggerGameOver() {
    state = 'gameover';
    AUDIO.stopMusic();
    AUDIO.playGameOver();
    finalScoreText.textContent = 'SCORE: ' + score;
    hud.classList.add('hidden');
    pauseHint.classList.add('hidden');
    bossBarWrap.style.display = 'none';
    gameOverScreen.classList.remove('hidden');
  }

  function triggerLevelClear() {
    if (level >= TOTAL_LEVELS) {
      triggerVictory();
      return;
    }
    state = 'levelclear';
    AUDIO.playLevelClear();
    levelClearText.textContent = 'SCORE: ' + score + '   |   SECTOR ' + level + ' CLEARED';
    levelClearScreen.classList.remove('hidden');
  }

  function triggerVictory() {
    state = 'victory';
    AUDIO.stopMusic();
    AUDIO.startMusic('victory');
    victoryText.textContent = 'FINAL SCORE: ' + score;
    victoryScreen.classList.remove('hidden');
    hud.classList.add('hidden');
    pauseHint.classList.add('hidden');
  }

  function goToNextLevel() {
    level++;
    levelClearScreen.classList.add('hidden');
    bullets = []; enemyBullets = []; particles = []; powerups = [];
    resetPlayer();
    invuln = 0.5;
    loadLevel(level);
    state = 'playing';
    updateHUD();
    AUDIO.startMusic('main');
  }

  // ============================================================
  // BUTTON WIRING
  // ============================================================
  el('startBtn').addEventListener('click', () => {
    AUDIO.init(); AUDIO.resume();
    AUDIO.playUIClick();
    startScreen.classList.add('hidden');
    startNewGame();
  });

  el('muteBtnStart').addEventListener('click', () => {
    AUDIO.init();
    toggleMute();
  });

  el('resumeBtn').addEventListener('click', () => { AUDIO.playUIClick(); togglePause(); });

  el('restartFromPauseBtn').addEventListener('click', () => {
    AUDIO.playUIClick();
    pauseScreen.classList.add('hidden');
    AUDIO.stopMusic();
    startNewGame();
  });

  el('nextLevelBtn').addEventListener('click', () => {
    AUDIO.playUIClick();
    goToNextLevel();
  });

  el('retryBtn').addEventListener('click', () => {
    AUDIO.playUIClick();
    gameOverScreen.classList.add('hidden');
    startNewGame();
  });

  el('playAgainBtn').addEventListener('click', () => {
    AUDIO.playUIClick();
    victoryScreen.classList.add('hidden');
    AUDIO.stopMusic();
    startNewGame();
  });

  // init render once before start so canvas isn't blank
  resetPlayer();
  bullets = []; enemyBullets = []; enemies = []; particles = []; powerups = [];
})();
